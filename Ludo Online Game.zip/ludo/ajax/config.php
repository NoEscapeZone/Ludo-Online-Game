<?php

$host = 'localhost';
$user = 'root';
$passwd = '';
$db = 'ludo1';


$roundTime = 20 * 1000;
$noMoveTime = 3 * 1000;

$timeToRoomRemove = 15 * 1000 * 60;
$skipTurnsToKick = 3;

$C_boardSize = 56;

$C_pawnStart = [
    "R" => 1,
    "G" => 29,
    "B" => 15,
    "Y" => 43
];

$C_pawnEnterBase = [
    "R" => 56,
    "G" => 28,
    "B" => 14,
    "Y" => 42
];
?>