import { Game } from "./modules/Game.js"

var game = new Game();